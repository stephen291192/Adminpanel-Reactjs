import logo from './logo.svg';
// import './App.css';
import '../src/style/mystyle.css';
import Sidebar from './component/Sidebar';
import { BrowserRouter,Route,Routes } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Comment from './pages/Comment';
import About from './pages/About';
import Header from './component/Header';
function App() {
  return (
    <div>
    <BrowserRouter>
    
       <Sidebar>
        <Routes>
          <Route path='/' element={<Dashboard />}/>
          <Route path='/comment' element={<Comment />}/>
          <Route path='/about' element={<About />}/>
          
        
        </Routes>
       </Sidebar>
      </BrowserRouter>
    </div>
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
  );
}

export default App;
