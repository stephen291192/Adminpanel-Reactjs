import React from 'react'
import Header from '../component/Header'
export default function About() {
  return (
    <div>
        <Header />
        <h3>About Page</h3>
    </div>
  )
}
