import React from 'react'
import Header from '../component/Header'
export default function Dashboard() {
  return (
    <div>
        <Header />
        <h3>Dashboard Page</h3>
    </div>
  )
}
