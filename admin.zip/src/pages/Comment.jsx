import React from 'react'
import Header from '../component/Header'
export default function Comment() {
  return (
    <div>
        <Header />
        <h3>Comment Page</h3></div>
  )
}
