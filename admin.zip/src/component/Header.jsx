import React from 'react'

export default function Header() {
  return (
    <div>
        <div className="headerContainer">
            <div className="Headertext">
                Welcome MedPlus
            </div>
        </div>
    </div>
  )
}
