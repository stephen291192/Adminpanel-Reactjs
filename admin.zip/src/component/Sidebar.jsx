import React, { Children } from 'react'
import Logo from '../Logo.png'
import { FaBeer, FaBars} from 'react-icons/fa';
import {RiDashboardFill,RiContactsLine}from 'react-icons/ri'
import {AiOutlineComment} from'react-icons/ai'
import{BiSolidContact} from 'react-icons/bi'
import { NavLink } from 'react-router-dom';
import { useState } from 'react';
export default function Sidebar({children}) {

    const [isopen,setIsopen]= useState(false)
        const toggle =()=> setIsopen(!isopen)    
    const menuItem =[
        {
            path:"/",
            name:"Dashboard",
            icon:<RiDashboardFill/>,
        },
        {
            path:"/comment",
            name:"Comment",
            icon:<AiOutlineComment/>,
        },
        {
            path:"/about",
            name:"About",
            icon:<RiContactsLine/>,
        },
        {
            path:"/abouts",
            name:"Contact",
            icon:<BiSolidContact/>,
        },

    ]

  return (
    <div className='container'>
        <div style={{width: isopen? "300px" : "50px"}} className="sidebar">
            <div className="top-section">
                <h1 style={{display:isopen ? "block" :"none" }}className="logo">
                    Logo
                     </h1>
                <div style={{marginLeft:isopen ? "150px" : "0px"}}className="bars">
                    <FaBars onClick={toggle} className='cusor-pointer'/>
                </div>
            </div>
            {   menuItem.map((x,i)=>(
                    <NavLink to={x.path} key={i} className="links" activeclassName="active" >
                        <div className="icon">
                            {x.icon}
                        </div>
                        <div style={{display:isopen ? "block" :"none" }} className="link-text">
                            {x.name}
                        </div>

                    </NavLink>
            ))

            }
        </div>
        <main>{children}
        </main>

      
    </div>
  )
}
